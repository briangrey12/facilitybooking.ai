export default function Home() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>FacilityBooking.ai</h1>
      <p>This is a clean Next.js launch-ready template.</p>
    </div>
  );
}
