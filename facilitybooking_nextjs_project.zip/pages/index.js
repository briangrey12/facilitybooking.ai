export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '2em' }}>
      <h1>Welcome to FacilityBooking.ai</h1>
      <p>The platform is under construction. Please check back soon!</p>
    </div>
  );
}
